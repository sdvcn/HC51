#ifndef __MAIN_H
#define __MAIN_H

#define debug

#define bool     unsigned char
#define uchar    unsigned char
#define uint     unsigned int
#define true     1
#define false    0

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"

void i2c_LowLevel_Init(void);
void i2c_DeInit(void);
void i2c_Init(void);

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "myiic.h"

#include "usart.h"
#include "ADSP9960_platform.h"
#include "SparkFun_ADSP9960.h"

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
