/**
  ******************************************************************************
  * @file    GPIO/IOToggle/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and peripherals
  *          interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h" 
#include "systime.h"
#include "LED.H"
#include "type.h"
#include "usart.h"
#include "delay.h"

extern unsigned char MODE;
extern struct LIGHT Light;
extern unsigned char light_flag_time;

 
void NMI_Handler(void)
{
}
 
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}
 
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

 
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}
 
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}
 
void SVC_Handler(void)
{
}
 
void DebugMon_Handler(void)
{
}
 
void PendSV_Handler(void)
{
}
 
void SysTick_Handler(void)
{
}
void TIM2_IRQHandler(void)
{


	TIM_ClearITPendingBit(TIM2, TIM_IT_Update );
	giv_sys_time ++;
	if((giv_sys_time % 2) == 0)
	{
		
	}
	if((giv_sys_time % 500) == 0)
	{
		
	}
	
	if((giv_sys_time % 200) == 0)
	{
			
	}
	
	if((giv_sys_time % 1000) == 0)
	{
			light_flag_time = 1;
	}
	if((giv_sys_time %20) == 0)
	{
	
	}
	if((giv_sys_time % 600000) == 0)     //���ӱ�־
	{
	
	}
	if((giv_sys_time % 10000) == 0)     //���־
	{
			Sec  = true;	 
			Light.timeout++ ;
		
	}	 
	if((giv_sys_time % 20000) == 0)     //�����־
	{
		         
	}
		switch(MODE)
		{
						case 0:
			case 1:
				break;

			case 2:
				break;
			default:
				break;
		}

//	if(DMA_GetFlagStatus(DMA1_FLAG_TC4)!=RESET)	//�ж�ͨ��4�������
//	{
//		DMA_ClearFlag(DMA1_FLAG_TC4);//���ͨ��4������ɱ�־
//		UART1.Trans_Busy = false;
//	}
//	if((UART1.Trans_Busy != true) && (UART1.Trans_Busy != false))
//	{
//		UART1.Trans_Busy = false;
//	}
	
}
/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/
