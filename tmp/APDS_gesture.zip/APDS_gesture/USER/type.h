#ifndef __TYPE_H
#define __TYPE_H
struct LIGHT
{
	unsigned short am[10];
	unsigned short ambient_light;
	unsigned short ambient_light_l;
	unsigned short last_light;
	unsigned short light_diff;
	unsigned short red_light;
	unsigned short green_light;
	unsigned short blue_light;
	unsigned short close_light;
	unsigned short open_light;
	unsigned char test_flag;
	unsigned char timeout;
	unsigned char testout;
	
};


#endif /* __TYPE_H */