/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "delay.h"
#include "usart.h"
#include "EXTI.h"
#include "LED.h"
#include "watchdog.h"
#include "systime.h"
#include "type.h"


/*******************************************/

#define LIGHT_INT_HIGH  1000 // High light level for interrupt
#define LIGHT_INT_LOW   20   // Low light level for interrupt


struct LIGHT Light;

int isr_flag = 0;
uint16_t threshold = 0;
unsigned char MODE = 0;
unsigned char light_flag_time;
unsigned char num =0 ;
void print_crlf(void);
/*******************************************/

void do_mode()
{
	static unsigned char i;
	static unsigned short temp;
	Uart1_Comunication();
	if(light_flag_time == 1)//100ms���ն�ȡʱ�䵽
	{
		light_flag_time = 0;
		readAmbientLight(&Light.am[num++%10]);
		clearAmbientLightInt(); 
		if(Light.am[9] - Light.am[0] < 2)
		{
			temp = Light.ambient_light_l;
			Light.ambient_light_l = 0;
			for(i = 0;i<10;i++)
			{
				Light.ambient_light_l += Light.am[i];
			}
			Light.ambient_light_l /= 10;
		}
		if(abs(Light.ambient_light_l - temp) < 10)
		{
			Light.ambient_light = Light.ambient_light_l;
		}
//		printf("AT+CIPSEND=0,11\r\n");
//		delay_ms(100);
//		printf("LED1:%6d\r\n",Light.ambient_light);
	}
	
	if(Light.test_flag == 1)//�ϲ���Ʊ��λ
	{
	
		Light.testout = 0;
		if(Light.timeout<15)
		{
			if(abs(Light.ambient_light - Light.last_light) > Light.light_diff)
			{
				Light.testout = 1;
				LED0 = 0;
				Light.test_flag = 3; //������Ҫ�����ϲ�����
			}
		}
		else 
		{
			Light.test_flag = 3; 
			LED0 = 1;
		}
		if(Light.test_flag == 3)
		{
			Light.test_flag = 0;
			//a5 04 01 81 00 84 5a
			printf("AT+CIPSEND=0,7\r\n");
			delay_ms(100);
			printf("%c%c%c%c%c%c%c\r\n",0xa5,0x04,0x01,0x81,Light.testout,0x84^Light.testout,0x5a);
			//printf("LED1:%6d %6d\r\n",Light.ambient_light,Light.last_light);
			Light.last_light = Light.ambient_light;
			Light.timeout = 0;
		}
		
	}
}

int main
	(void)
{

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	 //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	Init_WatchDog();
	delay_init();	//��ʱ��ʼ
	LED_Init();
	EXTIX_Init();
	URAT1_init(115200);

	DMA_Uart1Tx_Config(16);
	DMA_Uart1Rx_Config(128);	
	DMA_UART1_NVIC_config();	
	LED1 = 1;
	LED0 = 1;
	init_time();
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	
	printf("AT+CIPMUX=1\r\n");
	LED1 = 0;
	delay_ms(50);
	printf("AT+CIPSERVER=1,1001\r\n");
	LED0 = 0;
	delay_ms(1000);
	ADSP_9960_Init();

	setLightIntLowThreshold(LIGHT_INT_LOW);
	setLightIntHighThreshold(LIGHT_INT_HIGH);
	enableLightSensor(false);
	getLightIntLowThreshold(&threshold);
	getLightIntHighThreshold(&threshold); 
	setAmbientLightIntEnable(1);
	ADSP_Delay(500);
	readAmbientLight(&Light.last_light);
	Light.light_diff = 50;
  while (1)
  {
		do_mode();
  }
}
/***************************************************************************************/

/***************************************************************************************/
void print_crlf()
{
  printf("\r\n");
}

