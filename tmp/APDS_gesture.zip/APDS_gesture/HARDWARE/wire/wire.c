/*
  TwoWire.cpp - TWI/I2C library for Wiring & Arduino
  Copyright (c) 2006 Nicholas Zambetti.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 
  Modified 2012 by Todd Krein (todd@krein.org) to implement repeated starts
*/

//extern "C" {
//  #include <stdlib.h>
//  #include <string.h>
//  #include <inttypes.h>
//  #include "twi.h"
//}


#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

#include "twi.h"
#include "Wire.h"


// Initialize Class Variables //////////////////////////////////////////////////

//static uint8_t Wire_rxBuffer[BUFFER_LENGTH];
static uint8_t Wire_rxBufferIndex = 0;
static uint8_t Wire_rxBufferLength = 0;

static uint8_t Wire_txAddress = 0;
//static uint8_t Wire_txBuffer[BUFFER_LENGTH];
static uint8_t Wire_txBufferIndex = 0;
static uint8_t Wire_txBufferLength = 0;
static uint8_t Wire_transmitting = 0;

void (*Wire_user_onRequest)(void);
void (*Wire_user_onReceive)(int);

// Constructors ////////////////////////////////////////////////////////////////

void Wire_TwoWire()
{
}

// Public Methods //////////////////////////////////////////////////////////////

void Wire_begin_(void)
{
  Wire_rxBufferIndex = 0;
  Wire_rxBufferLength = 0;

  Wire_txBufferIndex = 0;
  Wire_txBufferLength = 0;

  twi_init();
}

void Wire_begin_u8(uint8_t address)
{
  twi_setAddress(address);
  twi_attachSlaveTxEvent(Wire_onRequestService);
  twi_attachSlaveRxEvent(Wire_onReceiveService);
  Wire_begin_();
}

void Wire_begin_8(int address)
{
  Wire_begin_u8((uint8_t)address);
}

void Wire_end(void)
{
  twi_disable();
}

void Wire_setClock(uint32_t frequency)
{
  TWBR = ((F_CPU / frequency) - 16) / 2;
}

uint8_t Wire_requestFrom_4(uint8_t address, uint8_t quantity, uint32_t iaddress, uint8_t isize, uint8_t sendStop)
{
	uint8_t read;
  if (isize > 0) {
  // send internal address; this mode allows sending a repeated start to access
  // some devices' internal registers. This function is executed by the hardware
  // TWI module on other processors (for example Due's TWI_IADR and TWI_MMR registers)

  Wire_beginTransmission_8(address);

  // the maximum size of internal address is 3 bytes
  if (isize > 3){
    isize = 3;
  }

  // write internal register address - most significant byte first
  while (isize-- > 0)
    Wire_write((uint8_t)(iaddress >> (isize*8)));
  Wire_endTransmission_u8(false);
  }

  // clamp to buffer length
  if(quantity > BUFFER_LENGTH){
    quantity = BUFFER_LENGTH;
  }
  // perform blocking read into buffer
  read = twi_readFrom(address, Wire_rxBuffer, quantity, sendStop);
  // set rx buffer iterator vars
  Wire_rxBufferIndex = 0;
  Wire_rxBufferLength = read;

  return read;
}

uint8_t Wire_requestFrom__3(uint8_t address, uint8_t quantity, uint8_t sendStop) {
	return Wire_requestFrom_4((uint8_t)address, (uint8_t)quantity, (uint32_t)0, (uint8_t)0, (uint8_t)sendStop);
}

uint8_t Wire_requestFrom_2(uint8_t address, uint8_t quantity)
{
  return Wire_requestFrom_3((uint8_t)address, (uint8_t)quantity, (uint8_t)true);
}

uint8_t Wire_requestFrom_2int(int address, int quantity)
{
  return Wire_requestFrom_3((uint8_t)address, (uint8_t)quantity, (uint8_t)true);
}

uint8_t Wire_requestFrom_3int(int address, int quantity, int sendStop)
{
  return Wire_requestFrom_3((uint8_t)address, (uint8_t)quantity, (uint8_t)sendStop);
}

void Wire_beginTransmission(uint8_t address)
{
  // indicate that we are transmitting
  Wire_transmitting = 1;
  // set address of targeted slave
  Wire_txAddress = address;
  // reset tx buffer iterator vars
  Wire_txBufferIndex = 0;
  Wire_txBufferLength = 0;
}

void Wire_beginTransmission_8(int address)
{
  Wire_beginTransmission((uint8_t)address);
}

//
//	Originally, 'endTransmission' was an f(void) function.
//	It has been modified to take one parameter indicating
//	whether or not a STOP should be performed on the bus.
//	Calling endTransmission(false) allows a sketch to 
//	perform a repeated start. 
//
//	WARNING: Nothing in the library keeps track of whether
//	the bus tenure has been properly ended with a STOP. It
//	is very possible to leave the bus in a hung state if
//	no call to endTransmission(true) is made. Some I2C
//	devices will behave oddly if they do not see a STOP.
//
uint8_t Wire_endTransmission_u8(uint8_t sendStop)
{
  // transmit buffer (blocking)
  int8_t ret = twi_writeTo(Wire_txAddress, Wire_txBuffer, Wire_txBufferLength, 1, sendStop);
  // reset tx buffer iterator vars
  Wire_txBufferIndex = 0;
  Wire_txBufferLength = 0;
  // indicate that we are done transmitting
  Wire_transmitting = 0;
  return ret;
}

//	This provides backwards compatibility with the original
//	definition, and expected behaviour, of endTransmission
//
uint8_t Wire_endTransmission_(void)
{
  return Wire_endTransmission_u8(true);
}

// must be called in:
// slave tx event callback
// or after beginTransmission(address)
int Wire_write(uint8_t data)
{
  if(Wire_transmitting){
  // in master transmitter mode
    // don't bother if buffer is full
    if(Wire_txBufferLength >= BUFFER_LENGTH){
//      setWriteError();                 ��������Ҳ���
      return 0;
    }
    // put byte in tx buffer
    Wire_txBuffer[Wire_txBufferIndex] = data;
    ++Wire_txBufferIndex;
    // update amount in buffer   
    Wire_txBufferLength = Wire_txBufferIndex;
  }else{
  // in slave send mode
    // reply to master
    twi_transmit(&data, 1);
  }
  return 1;
}

// must be called in:
// slave tx event callback
// or after beginTransmission(address)
int Wire_write_(const uint8_t *data, int quantity)
{
	int i;
  if(Wire_transmitting){
  // in master transmitter mode
    for(i = 0; i < quantity; ++i){
      Wire_write(data[i]);
    }
  }else{
  // in slave send mode
    // reply to master
    twi_transmit(data, quantity);
  }
  return quantity;
}

// must be called in:
// slave rx event callback
// or after requestFrom(address, numBytes)
int Wire_available(void)
{
  return Wire_rxBufferLength - Wire_rxBufferIndex;
}

// must be called in:
// slave rx event callback
// or after requestFrom(address, numBytes)
int Wire_read(void)
{
  int value = -1;
  
  // get each successive byte on each call
  if(Wire_rxBufferIndex < Wire_rxBufferLength){
    value = Wire_rxBuffer[Wire_rxBufferIndex];
    ++Wire_rxBufferIndex;
  }

  return value;
}

// must be called in:
// slave rx event callback
// or after requestFrom(address, numBytes)
int Wire_peek(void)
{
  int value = -1;
  
  if(Wire_rxBufferIndex < Wire_rxBufferLength){
    value = Wire_rxBuffer[Wire_rxBufferIndex];
  }

  return value;
}

void Wire_flush(void)
{
  // XXX: to be implemented.
}

// behind the scenes function that is called when data is received
void Wire_onReceiveService(uint8_t* inBytes, int numBytes)
{
	uint8_t i;
  // don't bother if user hasn't registered a callback
  if(!Wire_user_onReceive){
    return;
  }
  // don't bother if rx buffer is in use by a master requestFrom() op
  // i know this drops data, but it allows for slight stupidity
  // meaning, they may not have read all the master requestFrom() data yet
  if(Wire_rxBufferIndex < Wire_rxBufferLength){
    return;
  }
  // copy twi rx buffer into local read buffer
  // this enables new reads to happen in parallel
  for(i = 0; i < numBytes; ++i){
    Wire_rxBuffer[i] = inBytes[i];    
  }
  // set rx iterator vars
  Wire_rxBufferIndex = 0;
  Wire_rxBufferLength = numBytes;
  // alert user program
  Wire_user_onReceive(numBytes);
}

// behind the scenes function that is called when data is requested
void Wire_onRequestService(void)
{
  // don't bother if user hasn't registered a callback
  if(!Wire_user_onRequest){
    return;
  }
  // reset tx buffer iterator vars
  // !!! this will kill any pending pre-master sendTo() activity
  Wire_txBufferIndex = 0;
  Wire_txBufferLength = 0;
  // alert user program
  Wire_user_onRequest();
}

// sets function called on slave write
void Wire_onReceive( void (*function)(int) )
{
  Wire_user_onReceive = function;
}

// sets function called on slave read
void Wire_onRequest( void (*function)(void) )
{
  Wire_user_onRequest = function;
}

// Preinstantiate Objects //////////////////////////////////////////////////////

//TwoWire Wire = TwoWire();

