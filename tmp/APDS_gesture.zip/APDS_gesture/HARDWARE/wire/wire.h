/*
  TwoWire.h - TWI/I2C library for Arduino & Wiring
  Copyright (c) 2006 Nicholas Zambetti.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

  Modified 2012 by Todd Krein (todd@krein.org) to implement repeated starts
*/

#ifndef TwoWire_h
#define TwoWire_h

#include <inttypes.h>
//#include "Stream.h"

#define BUFFER_LENGTH 32

// WIRE_HAS_END means Wire has end()
#define WIRE_HAS_END 1




    static uint8_t Wire_rxBuffer[BUFFER_LENGTH];
    static uint8_t Wire_rxBufferIndex;
    static uint8_t Wire_rxBufferLength;

    static uint8_t Wire_txAddress;
    static uint8_t Wire_txBuffer[BUFFER_LENGTH];
    static uint8_t Wire_txBufferIndex;
    static uint8_t Wire_txBufferLength;

    static uint8_t Wire_transmitting;
    static void (*user_onRequest)(void);
    static void (*user_onReceive)(int);
    static void Wire_onRequestService(void);
    static void Wire_onReceiveService(uint8_t*, int);

    void TwoWire(void);
    void Wire_begin_(void);
    void Wire_begin_u8(uint8_t address);
    void Wire_begin_8(int address);
    void Wire_end(void);
    void Wire_setClock(uint32_t);
    void Wire_beginTransmission(uint8_t);
    void Wire_beginTransmission_8(int);
    uint8_t Wire_endTransmission_(void);
    uint8_t Wire_endTransmission_u8(uint8_t);
    uint8_t Wire_requestFrom_2(uint8_t, uint8_t);
    uint8_t Wire_requestFrom_3(uint8_t, uint8_t, uint8_t);
	  uint8_t Wire_requestFrom_4(uint8_t, uint8_t, uint32_t, uint8_t, uint8_t);
    uint8_t Wire_requestFrom_2int(int, int);
    uint8_t Wire_requestFrom_3int(int, int, int);
    int Wire_write(uint8_t);
    int Wire_write_(const uint8_t *, int);
    int Wire_available(void);
    int Wire_read(void);
    int Wire_peek(void);
    void Wire_flush(void);
    void Wire_onReceive( void (*)(int) );
    void Wire_onRequest( void (*)(void) );

//    inline int Wire_write_ul(unsigned long n) { return Wire_write((uint8_t)n); }
//    inline int Wire_write_l(long n) { return Wire_write((uint8_t)n); }
//    inline int Wire_write_u(unsigned int n) { return Wire_write((uint8_t)n); }
//    inline int Wire_write_int(int n) { return Wire_write((uint8_t)n); }
//    //using Print::write;




#endif

